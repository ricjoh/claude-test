<?php

$header = array(
	'title' => 'This is my Title',
	'subhead' => 'subheading',
	'body' => 'Lorem ipsum dolor est sit amet.',
	'footer' => 'Lorem footre ipsum dolor est sit amet.'
);

$lines = array(
	[ 'data' => 'thing' ],
	[ 'data' => 'stuff' ],
	[ 'data' => 'fluff' ] );

include( 'template.php' );
