<?php
// namespace Tracker\Controllers;
use Phalcon\Mvc\Controller;
// use Phalcon\Http\Response;

class ShipPalletController extends Controller
{


}
